import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-request',
  templateUrl: './my-request.component.html',
  styleUrls: ['./my-request.component.scss']
})
export class MyRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
