import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-transporter',
  templateUrl: './search-transporter.component.html',
  styleUrls: ['./search-transporter.component.scss']
})
export class SearchTransporterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
