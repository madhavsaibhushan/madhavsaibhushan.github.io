import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-service-provider',
  templateUrl: './booking-service-provider.component.html',
  styleUrls: ['./booking-service-provider.component.scss']
})
export class BookingServiceProviderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
