import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-rates',
  templateUrl: './booking-rates.component.html',
  styleUrls: ['./booking-rates.component.scss']
})
export class BookingRatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
