import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-inquiries',
  templateUrl: './my-inquiries.component.html',
  styleUrls: ['./my-inquiries.component.scss']
})
export class MyInquiriesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
