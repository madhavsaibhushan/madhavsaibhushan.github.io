import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-instructions',
  templateUrl: './shipping-instructions.component.html',
  styleUrls: ['./shipping-instructions.component.scss']
})
export class ShippingInstructionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
