import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-container-booking',
  templateUrl: './container-booking.component.html',
  styleUrls: ['./container-booking.component.scss']
})
export class ContainerBookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
