import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-container-booking-list',
  templateUrl: './container-booking-list.component.html',
  styleUrls: ['./container-booking-list.component.scss']
})
export class ContainerBookingListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
