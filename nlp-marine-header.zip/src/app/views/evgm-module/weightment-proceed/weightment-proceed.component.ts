import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weightment-proceed',
  templateUrl: './weightment-proceed.component.html',
  styleUrls: ['./weightment-proceed.component.scss']
})
export class WeightmentProceedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
