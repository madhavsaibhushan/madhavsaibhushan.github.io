import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-weightment-request',
  templateUrl: './search-weightment-request.component.html',
  styleUrls: ['./search-weightment-request.component.scss']
})
export class SearchWeightmentRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
