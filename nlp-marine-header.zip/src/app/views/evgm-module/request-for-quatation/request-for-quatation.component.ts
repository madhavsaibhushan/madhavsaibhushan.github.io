import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-for-quatation',
  templateUrl: './request-for-quatation.component.html',
  styleUrls: ['./request-for-quatation.component.scss']
})
export class RequestForQuatationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
