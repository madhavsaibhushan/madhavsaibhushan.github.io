import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-weighments',
  templateUrl: './my-weighments.component.html',
  styleUrls: ['./my-weighments.component.scss']
})
export class MyWeighmentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
