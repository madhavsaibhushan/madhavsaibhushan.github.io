import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-caf',
  templateUrl: './caf.component.html',
  styleUrls: ['./caf.component.scss']
})
export class CafComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
