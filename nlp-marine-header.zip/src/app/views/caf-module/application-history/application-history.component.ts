import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application-history',
  templateUrl: './application-history.component.html',
  styleUrls: ['./application-history.component.scss']
})
export class ApplicationHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
