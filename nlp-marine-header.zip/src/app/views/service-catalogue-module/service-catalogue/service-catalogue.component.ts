import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-catalogue',
  templateUrl: './service-catalogue.component.html',
  styleUrls: ['./service-catalogue.component.scss']
})
export class ServiceCatalogueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
