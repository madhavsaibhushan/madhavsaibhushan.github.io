import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-agreement',
  templateUrl: './payment-agreement.component.html',
  styleUrls: ['./payment-agreement.component.scss']
})
export class PaymentAgreementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
