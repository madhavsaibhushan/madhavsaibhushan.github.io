import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pga-registration',
  templateUrl: './pga-registration.component.html',
  styleUrls: ['./pga-registration.component.scss']
})
export class PgaRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
